import { Component } from '@angular/core';
import { Planet } from '../models/planet';
import { Subscription } from 'rxjs';
import { PlanetService } from '../services/planet.service';

@Component({
  selector: 'app-planets',
  templateUrl: './planets.component.html',
  styleUrls: ['./planets.component.scss']
})
export class PlanetsComponent {
  planets: Planet[] = [];
  subscription: Subscription = new Subscription();

  constructor(private planetService: PlanetService) { }

  ngOnInit(): void {
    this.subscription.add(
      this.planetService.getAllPlanet().subscribe((data) => {
        this.planets = data;
      }
      ));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
