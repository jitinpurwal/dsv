import { Component } from '@angular/core';
import { Film } from '../models/film';
import { Subscription } from 'rxjs';
import { FilmService } from '../services/film.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-film',
  templateUrl: './film.component.html',
  styleUrls: ['./film.component.scss']
})
export class FilmComponent {
  url: string | null = "";
  film: Film | {} = {};  
  subscription: Subscription = new Subscription();

  constructor(private filmService: FilmService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.url =  this.route.snapshot.queryParamMap.get('url');
      if(this.url)
      this.subscription.add(
        this.filmService.getFilm(this.url).subscribe((data) => {
          this.film = data;
        }
        ));
    })
    
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
