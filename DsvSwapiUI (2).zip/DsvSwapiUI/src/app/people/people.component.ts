import { Component } from '@angular/core';
import { People } from '../models/people';
import { Subscription } from 'rxjs';
import { PeopleService } from '../services/people.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.scss']
})
export class PeopleComponent {
  url: string | null = "";
  people: People = new People();  
  subscription: Subscription = new Subscription();

  constructor(private peopleService: PeopleService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      this.url =  this.route.snapshot.queryParamMap.get('url');
      if(this.url)
      this.subscription.add(
        this.peopleService.getPeople(this.url).subscribe((data) => {
          this.people = data;
        }
        ));
    })
    
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
