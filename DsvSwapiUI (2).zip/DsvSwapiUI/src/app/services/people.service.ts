import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PeopleService {
  private apiUrl = 'https://localhost:7200/api/';

  constructor(private http: HttpClient) {}

  getAllPeople(): Observable<any> {
    return this.http.get(`${this.apiUrl}people/getAllPeople`);
  }

  getPeople(url: string): Observable<any> {
    return this.http.get(`${this.apiUrl}people/getPeople?url=` + url);
  }
}
