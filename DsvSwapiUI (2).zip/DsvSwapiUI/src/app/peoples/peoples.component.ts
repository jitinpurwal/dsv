import { Component, OnDestroy, OnInit } from '@angular/core';
import { People } from '../models/people';
import { PeopleService } from '../services/people.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-peoples',
  templateUrl: './peoples.component.html',
  styleUrls: ['./peoples.component.scss']
})
export class PeoplesComponent implements OnInit, OnDestroy {
  peoples: People[] = [];
  subscription: Subscription = new Subscription();

  constructor(private peopleService: PeopleService) { }

  ngOnInit(): void {
    this.subscription.add(
      this.peopleService.getAllPeople().subscribe((data) => {
        this.peoples = data;
      }
      ));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
