export interface Film {
    episode_id: number;
    vehicles: string[];
    url: string;
    starships: string[];
    title: string;
    species: string[];
    producer: string;
    planets: string[];
    director: string;
    characters: string[];
    opening_crawl: string;
}