export interface Planet {
    residents: string[];
    films: string[];
    rotation_period: string;
    url: string;
    gravity: string;
    terrain: string;
    climate: string;
    diameter: string;
    created: string;
    name: string;
    surface_water: string;
    population: string;
    orbital_period: string;
    edited: string;
}