import { Component } from '@angular/core';
import { Film } from '../models/film';
import { Subscription } from 'rxjs';
import { FilmService } from '../services/film.service';

@Component({
  selector: 'app-films',
  templateUrl: './films.component.html',
  styleUrls: ['./films.component.scss']
})
export class FilmsComponent {
  films: Film[] = [];
  subscription: Subscription = new Subscription();

  constructor(private fimsService: FilmService) { }

  ngOnInit(): void {
    this.subscription.add(
      this.fimsService.getAllFilm().subscribe((data) => {
        this.films = data;
      }
      ));
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
