import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PeoplesComponent } from './peoples/peoples.component';
import { PeopleComponent } from './people/people.component';
import { PlanetsComponent } from './planets/planets.component';
import { PlanetComponent } from './planet/planet.component';
import { FilmsComponent } from './films/films.component';
import { FilmComponent } from './film/film.component';

const routes: Routes = [
  { path: '', redirectTo: "peoples", pathMatch:'full'},
  { path: 'peoples', component: PeoplesComponent },
  { path: 'people', component: PeopleComponent},
  { path: 'planets', component: PlanetsComponent},
  { path: 'planet', component: PlanetComponent},
  { path: 'films', component: FilmsComponent},
  { path: 'film', component: FilmComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
